package Data_manip;

import java.sql.*;
import java.util.Scanner;

public class BankMain {

	public static void main(String[] args) {
		
		
		
		/*
		BG3.CreateAccount("Ali", "Boukabous", "28/10/1995", 1, 12000F);
		BG3.CreateAccount("Sohaib", "Bouzidi", "05/10/1995", 2, 1500F);
		BG3.ShowCustomersAccount();
		if(BG3.transferFromTo(12000, BG3.searchAccountByID(1), BG3.searchAccountByID(2)))
			System.out.println("\nSuccessfully Transfered bitch\n");
		else
			System.out.println("\nnik mok nakek el tchoumir, 9ewed b3id\n");
		
		BG3.ShowCustomersAccount();
		
		//Account account = new Account(3, 18520);
		
		if(BG3.deleteAccount(BG3.searchAccountByID(2)))
			System.out.println("\nSuccesfully Deleted The Account rabak\n");
		else
			System.out.println("\nFailed To Delete rabak\n");
			
		BG3.ShowCustomersAccount();*/
		Connection conn = null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://192.168.1.4:3306/g3bank_db?SSL=false", "HP", "Vbnvbn123");
			/*Statement stml = conn.createStatement();
			ResultSet rs = stml.executeQuery("select * from bank_informations");
			 while(rs.next()) {
				 System.out.println(rs.getString("name"));
				 System.out.println(rs.getString("address"));
			 }*/
		} catch (Exception e) {
			e.printStackTrace();
		}
		/*
		System.out.println("\n*** Hello To G3 Bank Why Are You GAY? ***\n");
		
		Scanner SC = new Scanner(System.in);
		
		Bank BG3 = new Bank("BG3","Douaouda City");
		while(true) {
		System.out.println("(1) Create An Account\n(2) Delete An Account\n(3) Search A Customer's Account\n(4) Transfer MONEY baby\n(5) Show All Accounts\n(6) Search Customer\n(7) Save to DATABASE");
		
		int C = SC.nextInt();
		
		switch (C) {
		case 1: 
			System.out.println("Please Enter The First Name Rabak\n");
			String FN = SC.next();
			System.out.println("Please Enter The Last Name Nik Mok\n");
			String LN = SC.next();
			System.out.println("Please Enter The Birth Day Ya Sbi\n");
			String BD = SC.next();
			System.out.println("Please Enter The Account's ID Rabak\n");
			int IdAccount = SC.nextInt();
			System.out.println("Please Enter The Money Amount Zebi\n");
			float Montant = SC.nextFloat();
			BG3.CreateAccount(FN, LN, BD, IdAccount, Montant);
			break;
			
		case 5:
			BG3.ShowCustomersAccount();
			break;
		
		
		case 7:
			try {
				PreparedStatement preS = conn.prepareStatement("INSERT INTO PERSON(FN, LN, DB) VALUES (?, ?, ?)");
				preS.setString(1, BG3.getCustomerList().get(0).getFN());
				preS.setString(2, BG3.getCustomerList().get(0).getLN());
				preS.setString(3, BG3.getCustomerList().get(0).getBD());
				
				preS.execute();
				
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		}
		*/
		
	}

}
