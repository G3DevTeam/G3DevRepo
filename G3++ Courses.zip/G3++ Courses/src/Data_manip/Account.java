package Data_manip;

public class Account {
	private int ID ;
	private float Montant ;

	public Account (int ID , float Montant) {
		this.ID=ID ;
		this.Montant=Montant ;
	}
	public int getID() {
		return ID ;
	}
	public float getMontant() {
		return Montant ;
	}
	public void setID(int ID) {
		this.ID=ID ;
	}
	public void setMontant(float Montant) {
		this.Montant=Montant ;
	}
	
}
