package Data_manip;

public class Circle extends Form {
	
	private float radius;

	public Circle(String Name, String color, float radius) {
		super(Name, color);
		this.radius = radius;
	}

	public float getRadius() {
		return radius;
	}

	public void setRadius(float radius) {
		this.radius = radius;
	}

	@Override
	public float Surface() {
		// TODO Auto-generated method stub
		return (float) (Math.pow(radius, 2)* 3.14);
	}

	@Override
	public float Perimeter() {
		
		return radius * 3.14f * 2.0f;
	}
	
	

}
