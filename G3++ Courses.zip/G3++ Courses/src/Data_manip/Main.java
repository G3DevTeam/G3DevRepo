package Data_manip;

public class Main {

	public static void main(String[] args) {
		
		Circle c = new Circle("Dowayra", "Rouge", 3);
		Rectangle r = new Rectangle("Moustatile", "Jaune", 4, 5);
		Square s = new Square("Mouraba3", "Blanc", 6);
		
		System.out.println("------------------- Circle ------------------");
		System.out.println(c.getName() + "  "+ c.getColor() + "  " + c.getRadius());
		System.out.println(c.Surface() + " :: " + c.Perimeter());
		
		System.out.println("------------------- Rectangle ------------------");
		System.out.println(r.getName() + "  "+ r.getColor() + "  " + r.getLength() + "  " + r.getWidth());
		System.out.println(r.Surface() + " :: " + r.Perimeter());
		
		System.out.println("------------------- Square ------------------");
		System.out.println(s.getName() + "  "+ s.getColor() + "  " + s.getLength());
		System.out.println(s.Surface() + " :: " + s.Perimeter());

	}

}
