package Data_manip;

import java.util.ArrayList;

public class Repertoire {
	
	private ArrayList<Contact> rep;

	public Repertoire() {
		rep = new ArrayList<Contact>();
	}
	
	
	
	public ArrayList<Contact> getRep() {
		return rep;
	}


	public void Add_Contact(Contact C) {
		if(!checkNumberExists(C)) 
			rep.add(C);
		else
			System.out.println("Attention!!! You CAN't ADD NEW CONTACT THAT HAVE THE SAME PHONE NUMBER");
	}
	
	public void Remove_Contact(int index) {
		rep.remove(index);
	}
	
	public Contact get_Iem_Contact(int index) {
		return getRep().get(index);
	}
	
	public boolean checkNumberExists(Contact C) {
		int index = 0;
		while(index < getRep().size()) {
			if(C.getPN().equals(getRep().get(index).getPN())) {
				return true;
			}
			index ++ ;
		}
		return false;
	}
	
	public void ShowAllContacts() {
		System.out.println("--------------- REPERTOIRE---------");
		if(getRep().size() != 0)
			for(int i = 0; i< getRep().size(); i++) {
				getRep().get(i).ShowInfo();
			}
		else
			System.out.println("LIST IS EMPTY");
	}

}
