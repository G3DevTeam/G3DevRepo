package Data_manip;

public class Person {
	private String FN ; 
	private String LN ;
	private String BD ;
	private int IdAccount ;
	
	public Person (String FN , String LN , String BD , int IdAccount) {
		this.FN=FN ;
		this.LN=LN ;
		this.BD=BD ;
		this.IdAccount=IdAccount ;
	}
	public String getFN() {
		return FN ;
	}
	public String getLN() {
		return LN ;
	}
	public String getBD() {
		return BD ;
	}
	public int getIdAccount() {
		return IdAccount ;
	}
	public void setFN(String FN) {
		this.FN=FN ;
	}
	public void setLN(String LN) {
		this.LN=LN ;
	}	
	public void setBD(String BD) {
		this.BD=BD ;
	}
	public void setIdAccunt (int IdAccount) {
		this.IdAccount=IdAccount ;
	}
}
