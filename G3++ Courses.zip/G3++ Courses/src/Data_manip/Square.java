package Data_manip;

public class Square extends Form {
	
	private float length;

	public Square(String Name, String color, float length) {
		super(Name, color);
		this.length = length;
		
	}

	public float getLength() {
		return length;
	}

	public void setLength(float length) {
		this.length = length;
	}

	@Override
	public float Surface() {
		
		return (float) Math.pow(length, 2);
	}

	@Override
	public float Perimeter() {
	
		return length * 4;
	}
	
	

}
