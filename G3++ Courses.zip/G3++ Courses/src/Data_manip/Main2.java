package Data_manip;

import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Statement;

public class Main2 {

	public static void main(String[] args) {
		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;
		PreparedStatement pstmt = null, pstmtDel = null;
		
		Scanner sc = new Scanner(System.in);
		
		while(true) {
			System.out.println("\n(1) Create A Persont\n(2) Delete An Account\n(3) Search A Customer's Account\n(4) Transfer MONEY baby\n(5) Show All Accounts\n(6) Search Customer\n(7) Save to DATABASE\n(8) EXIT RABAK");
						
			try {
				if(conn==null || conn.isClosed())
					conn = (Connection) DriverManager.getConnection("jdbc:mysql://192.168.1.2:3306/g3bank_db", "HP", "Vbnvbn123");
				
				System.out.println("Connection Successfull");
			    
			    pstmt = (PreparedStatement) conn.prepareStatement("Insert into person (FN, LN, DB) values (?, ?, ?)");
			    pstmtDel = (PreparedStatement) conn.prepareStatement("Delete from person where id_person=?");
			    int choice = sc.nextInt();
			    
			    switch(choice) {
			    case 1:
			    	System.out.println("Enter The First Name ya hmaaaarrrr");    
			    	String FN = sc.next();
			    	System.out.println("Enter The Last Name ya El No9ch");    

			    	    
					    String LN = sc.next();
				    	System.out.println("Enter The Birth Day Ya El Tiiizz");    

					    String DB = sc.next();
					    pstmt.setString(1, FN);
					    pstmt.setString(2, LN);
					    pstmt.setString(3, DB);
					    pstmt.execute();
					    break;
			    case 2:
			    	int id = sc.nextInt();
			    	pstmtDel.setInt(1, id);
			    	if(pstmtDel.execute())
			    		System.out.println("Succesfully Deleted");
			    	else
			    		System.out.println("Error");
			    	choice = 5;
			    	
			    case 5:
			    	stmt = (Statement) conn.createStatement();
				    rs = stmt.executeQuery("SELECT * FROM PERSON");
				    while (rs.next()) {
				    	System.out.println(rs.getInt("id_person")+"\t"+rs.getString("FN")+"\t"+rs.getString("LN")+ "\t"+rs.getDate("DB"));
				    }
				    break;
			    case 8:
			    	conn.close();
			    	System.exit(0);
			    	break;
			    	
			    
			    }
			    	
			    
			   
	
			    
			    
			    //conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				System.out.println("An Error Has Occured "+e.getMessage()+"\t"+e.getCause());
				e.printStackTrace();
			}	
		}
		
	}

}
