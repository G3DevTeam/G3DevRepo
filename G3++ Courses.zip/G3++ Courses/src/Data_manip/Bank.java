package Data_manip;

import java.util.ArrayList;

public class Bank {
	private String Name;
	private String Address;
	private ArrayList<Person> CustomerList;
	private ArrayList<Account> AccountList;
	
	public Bank (String Name, String Address) {
		this.Name=Name;
		this.Address=Address;
		CustomerList = new ArrayList<Person>();
		AccountList = new ArrayList<Account>();
	}

	public String getName() {
		return Name;
	}

	public void setName(String name) {
		Name = name;
	}

	public String getAddress() {
		return Address;
	}

	public void setAddress(String address) {
		Address = address;
	}

	public ArrayList<Person> getCustomerList() {
		return CustomerList;
	}

	public ArrayList<Account> getAccountList() {
		return AccountList;
	}
	
	
	public void CreateAccount (String FN, String LN, String BD, int IdAccount, float Montant) {
		if(Montant >= 1000) {
			
			Person Customer= new Person(FN,LN,BD, IdAccount);
			Account Acc = new Account(IdAccount, Montant);
			CustomerList.add(Customer);
			AccountList.add(Acc);
		}
		else System.out.println("nta fa9a9ir 9ewed");
	}
	public void ShowCustomersAccount () {
		for(int i=0 ; i<CustomerList.size(); i++) {
			System.out.println("Last Name: "+CustomerList.get(i).getLN() );
			System.out.println("First Name: "+CustomerList.get(i).getFN() );
			System.out.println("Account ID: "+CustomerList.get(i).getIdAccount());
			System.out.println("Funds: "+searchAccountByID(CustomerList.get(i).getIdAccount()).getMontant());
		}
	}
	
	public Account searchAccountByID(int ID) {
		for(int i=0 ; i<AccountList.size(); i++) {
			if(ID==AccountList.get(i).getID())
				return AccountList.get(i);
		}
		return null;
	}
	
	public Person SearchCustomer (String FN , String LN) {
		for(int i=0 ; i<CustomerList.size(); i++) {
			if(FN==CustomerList.get(i).getFN()&& LN==CustomerList.get(i).getLN()) {
				return CustomerList.get(i);
			}
		}
		return null;
	}
	public boolean transferFromTo(float sum, Account aFrom, Account aTo) {
		if(sum <= aFrom.getMontant()) {
			aFrom.setMontant( aFrom.getMontant()-sum);
			aTo.setMontant(aTo.getMontant()+sum);
			return true;
		}
		return false;
		
	}
	
	public boolean deleteAccount(Account acc) {
		for(int i=0 ; i<AccountList.size() ; i++) {
			if(acc.getID() == AccountList.get(i).getID()) {
				int tempID=AccountList.get(i).getID();
				AccountList.remove(i);
				for(int j=0 ; j<CustomerList.size() ; j++) {
					if(tempID == CustomerList.get(j).getIdAccount()) {
						CustomerList.remove(j);
						return true;
					}
				}
			}
		}
		return false;
		
	}
	
}

