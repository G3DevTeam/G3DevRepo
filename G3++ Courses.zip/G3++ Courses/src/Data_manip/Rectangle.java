package Data_manip;

public class Rectangle extends Form {
	
	private float length;
	private float width;

	public Rectangle(String Name ,String color ,float length ,float width) {
		super(Name, color);
		this.length = length;
		this.width = width;
	}

	public float getLength() {
		return length;
	}

	public void setLength(float length) {
		this.length = length;
	}

	public float getWidth() {
		return width;
	}

	public void setWidth(float width) {
		this.width = width;
	}

	@Override
	public float Surface() {
		
		return length * width;
	}

	@Override
	public float Perimeter() {
		// TODO Auto-generated method stub
		return (length + width) * 2;
	}
	
	

}
