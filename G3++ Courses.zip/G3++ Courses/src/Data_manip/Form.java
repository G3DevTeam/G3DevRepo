package Data_manip;

public abstract class Form {
	
	private String color;
	private String Name;
	
	public Form(String Name ,String color) {
		this.color = color;
		this.Name = Name;
	}
	
	public void setColor(String color) {
		this.color = color;
	}
	
	public String getColor() {
		return color;
	}

	public String getName() {
		return Name;
	}

	public void setName(String name) {
		Name = name;
	}
	
	public abstract float Surface();
	public abstract float Perimeter();
}
