package Data_manip;

public class Contact {
	
	private String FN;
	private String LN;
	private String PN;
	
	public Contact(String FN, String LN, String PN) {
		this.FN = FN;
		this.LN = LN;
		this.PN = PN;
	}
	
	

	public Contact(String fN, String pN) {
		FN = fN;
		PN = pN;
		LN = "UNDEFINED";
	}



	public String getFN() {
		return FN;
	}

	public String getLN() {
		return LN;
	}

	public String getPN() {
		return PN;
	}

	public void setFN(String fN) {
		FN = fN;
	}

	public void setLN(String lN) {
		LN = lN;
	}

	public void setPN(String pN) {
		PN = pN;
	}
	
	public void ShowInfo() {
		System.out.println("Prenom: "+ getFN());
		System.out.println("Nom: "+ getLN());
		System.out.println("Phone Number: "+ getPN());
	}
}
